import org.encog.engine.network.activation.ActivationTANH;
import org.encog.ml.MLMethod;
import org.encog.ml.MLResettable;
import org.encog.ml.MethodFactory;
import org.encog.ml.genetic.MLMethodGeneticAlgorithm;
import org.encog.ml.train.MLTrain;
import org.encog.neural.networks.BasicNetwork;
import org.encog.neural.networks.training.anneal.NeuralSimulatedAnnealing;
import org.encog.neural.pattern.FeedForwardPattern;

public class Brain {

	public Food nearestSmelledFood;
	public Cell nearestSmelledCell;
	

	public Brain() {

	}

	public void update(Cell cell) {

		handlePrio(cell);

	}
	
	public void handlePrio(Cell cell) {
		if (cell.gene.fightFlightPrio > 0) {
			searchForCell(cell);
		}
		else {
			searchForFood(cell);
		}
	}
	//CALVULATE A PRIPORITY GENE FOR AGGRESISION VS SMELL AND LETS SE WHATS MORE IMPORTANT
	
	public void searchForFood(Cell cell) {
		nearestSmelledFood = smellNearestFood(cell, cell.gene.smell);

		if (nearestSmelledFood != null) {
			if (nearestSmelledFood.getX() < cell.getX()+cell.gene.size/2) {
				cell.moveX(-cell.gene.speed);
			} else {
				cell.moveX(cell.gene.speed);
			}

			if (nearestSmelledFood.getY() < cell.getY()+cell.gene.size/2) {
				cell.moveY(-cell.gene.speed);
			} else {
				cell.moveY(cell.gene.speed);
			}
		}
	}
	
	//MAKE METHOD FOR AGRESSION.
	
	//Takes in this.cell
	public void searchForCell(Cell cell) {
		float sizeProcentThisComparedToFoundCell; //Is it bas to have this local?
		nearestSmelledCell = smellNearestCell(cell, cell.gene.smell);

		if (nearestSmelledCell != null) {
			sizeProcentThisComparedToFoundCell = (cell.gene.size/nearestSmelledCell.gene.size)*100;
			//Köra random 0-100/agression, om den landar inom procent range attackera.
			//gör temp lösning nedan utan aggression och probabilitet
			if (sizeProcentThisComparedToFoundCell > 100) {
				if (nearestSmelledCell.getX() < cell.getX()+cell.gene.size/2) {
					cell.moveX(-cell.gene.speed);
				} else {
					cell.moveX(cell.gene.speed);
				}

				if (nearestSmelledCell.getY() < cell.getY()+cell.gene.size/2) {
					cell.moveY(-cell.gene.speed);
				} else {
					cell.moveY(cell.gene.speed);
				}
			}
			else {
				searchForFood(cell);
			}
		}
	}
	
	public static Cell smellNearestCell(Cell cell, float smell) {

		int index = 0;
		float nearest = 999999999;

		for (int i = 0; i < Main.cells.size(); i++) {

			if (Math.sqrt((Main.cells.get(i).getX() - cell.getX()) * (Main.cells.get(i).getX() - cell.getX())
					+ (Main.cells.get(i).getY() - cell.getY()) * (Main.cells.get(i).getY() - cell.getY())) < nearest) {
				nearest = (float) Math
						.sqrt((Main.cells.get(i).getX() - cell.getX()) * (Main.cells.get(i).getX() - cell.getX())
								+ (Main.cells.get(i).getY() - cell.getY()) * (Main.cells.get(i).getY() - cell.getY()));
				index = i;
			}

		}

		if (nearest > smell) {
			return null;
		}

		return Main.cells.get(index);

	}


	public static Food smellNearestFood(Cell cell, float smell) {

		int index = 0;
		float nearest = 999999999;

		for (int i = 0; i < Main.food.size(); i++) {

			if (Math.sqrt((Main.food.get(i).getX() - cell.getX()) * (Main.food.get(i).getX() - cell.getX())
					+ (Main.food.get(i).getY() - cell.getY()) * (Main.food.get(i).getY() - cell.getY())) < nearest) {
				nearest = (float) Math
						.sqrt((Main.food.get(i).getX() - cell.getX()) * (Main.food.get(i).getX() - cell.getX())
								+ (Main.food.get(i).getY() - cell.getY()) * (Main.food.get(i).getY() - cell.getY()));
				index = i;
			}

		}

		if (nearest > smell) {
			return null;
		}

		return Main.food.get(index);

	}

}
